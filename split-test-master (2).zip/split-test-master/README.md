# <a href="https://github.com/rhildred/split-test" target="_blank">split-test</a>

An engine for splitting the traffic between sites.

